####################################################################################
###
### neptune
###
####################################################################################
# Allowed variables: WORKER_NAME CUSTOM_TEMPLATE CUSTOM_URL CUSTOM_PASS CUSTOM_ALGO CUSTOM_USER_CONFIG CUSTOM_CONFIG_FILENAME

echo "WORKER_NAME =             $WORKER_NAME"
#echo "CUSTOM_TEMPLATE =         $CUSTOM_TEMPLATE"
echo "CUSTOM_URL =              $CUSTOM_URL"
#echo "CUSTOM_PASS =             $CUSTOM_PASS"
#echo "CUSTOM_ALGO =             $CUSTOM_ALGO"
echo "CUSTOM_USER_CONFIG =      $CUSTOM_USER_CONFIG"
echo "CUSTOM_CONFIG_FILENAME =  $CUSTOM_CONFIG_FILENAME"


#!/usr/bin/env bash
[[ -e /hive/miners/custom ]] && . /hive/miners/custom/neptune/h-manifest.conf

# Set default values if not provided by HiveOS
WORKER_NAME=${WORKER_NAME:-$HOSTNAME}
CUSTOM_URL=${CUSTOM_URL:-"stratum+ssl://eu.poolhub.io:4444"}
CUSTOM_TEMPLATE=${CUSTOM_TEMPLATE:-"$WORKER_NAME"}
CUSTOM_PASS=${CUSTOM_PASS:-"x"}

# Default address
DEFAULT_ADDRESS="nolgam1wr5m8ve0mvzkmffgu6458vjslak5dr3cjamuu2c7ydkdnuzytl4hdg6uh294zcypgvmfrkhgd4v8vnmkczu33u7jzuvekm0frxytpznaegnhl6ncl5dq4v9hzfcdty9np56sestrj7w8u2czm02fjlqxzjc5nyjwn6a06l930fk0rlkt3pmsfudtkaanlws4xhfm9747268xtdca0egvkdtjku55e2hwjj2env504edrjetzpm7j947qegnc55f2tghlavye6gkt4ca7caaaa6pkr8q7cgn8xlcrc6ctslqj60dzm5yqtw3jac75tr7fwsr73hxrgjlq3qvq6na5tng8kqr4d04f57llnaj290a4nmcq0h9mrr5hgw48t5w5ssvn04mzapzxg9e03x0za7hkc0vkju85ecaj672r4r6j2kk7r4qcce0gyuk4s00zshv78glzdywht7xmwyk7rm4c8arqdl7geyh8hdrk379a0xafslqypdgrfj2frdnn5zlefnc7j4glzttmrxss3d7seqsu788vayel223a9dh44kwhk0wcp9xj89tv36nqdvhvs0ym6x43y0fmz24hmaa7sx9lt3gedta0s5k6nydcwr655dt0p2atumrzgy9qqayhg240wrkj7x88j2nyt2uya3ekhryyvdl0pcggtrstq33nwlh8jnz0xc50w4cdunwvw8luq6fhpttj02567vdtwu7yxrs0l9kwlnq3snfsyzchtug45c4cfzadcy28uwjnq52v4hruzwvw8wvxtl0228w36rl92jp889sx43g4ewtx6lxu7pwc4uxj03kd09yq7dvyhvy323gcj9q8j3puzn9en8zjxyqqdxcr7622lms7g6jykqag8ylfdrykww0ugjkslwmf74t8slp7pn6ln2hzyhpzgu0gd9f026z438djkw52pdf6rkjkcy24xf6knqduntyr2u3hgguem5v2gqjf2m25gwe6e3pz05pzcjy2p8gdal8qged4e0mxxgqqsgley6xvhwfntfz9264nppj24k3c78xw0te3nvjw67cjmacy5h4krxguhhtaqx0mmadh58zkmj8qfzpscy3f659ykemgwaqx9eer2ke3wm4hc4qm5scvsn2sat4sqv50tf95qgan55v2wa8880epfgtkddhnrh4wet33f3229w20g526neqq0hzphlwntrx5l4eznjhahjlws9nvyz0rjq4zxdjezph6yjqj08e5ugu7j3dp44prw78xregqkngh4c3vw4vtms2xcsrgyxuq4s3mzmsty468psrv0lawaq6xqs5qkctu5shfjaf7xf29jze9qutrk0tsyj6xy9st7dhud0x9hmkzlgsc4vuv5ursj5tlatqy7e553l4sr7d8ncut02w6fet4208dylavezule3fsv49fayqpzv7j8wyf89ayfypnuxx0r3mp6z83wajm6eeannana7fwfkem9mg3jsnuxf4lesxncexzjwd228eyldvnw3zjyt2gd98f4a0jyc93pl4lde5kadv9j8q9ntepalwkfyfdmgehmdhkkn9jv8swhnsnr96ktjyhwnw36fyx45z6dp9z3q677k4aaalq8c8za4yxjv9f8ezzrf90zne2qnkxjvfznf6naxxv2ry30cewnaml4uts5v05a3e2yju4zfg6hvs0acp02qj2rdacg3qc0x2u5fn74033lsjty8p966zl89ggtnsrxkuxh9s7kw7gxfgqxh34e6asx2mhj7sesag9a6tjxhtcsje0dc9h8wcqvnnjye3jkl4gmg0enlhmc8pq8tlxx50f9l649j6s356fqawxfvkwhn0l0wxq5puarh7w398tj423m88u5rs9a73gjhwj777nkzrghnjrtat0qks7df6xm5hw45zex6gr6hj9tz7zpvtqrtfy7k64ncxt2dnfxlgs8tkflyess5jvenhqvxuuysltxuxxh56puyyujk6dv7g7e3fprew2sgyq06ycam6zn44m7zvrcjsjpy3m82j8fnzztkzf07kkl74ahptt79wusyhppgsaqlcx239njkj6x0a6shkjp7lw8nd3acnyelrpxfdf97ce24hm9mp2u4c6mfzfn42jw5m2ym4e6tnfkc2t3qccrelegzhkcsgts7ar28hcawzsp363awlkylly7y7krs0z23l0s40ekn9wkxqqxur356u669p7cygvmchpe3mf88j8qf404q27eme3v6vsz7ujmnuj75sl4dmeepfat3d647than9u90ghhr8v75jlzf4ckhvxuwkecz8qfnl58auyrpj6jdvlpg2fpuh4gnqhdwny2gwe94l4kf57uku0e3xrc46afcfpyv59390vr9hc95ttx4t4ys6aghduf7vgjjuhnue4x5ln4gxhhxjn2ey9a4g7s80jhtw0pnd89zx926vqep6wd2ru58vtxw8hawq429qud227fwwf3gm2vr360lckjp8mahjxw0w6jv8jedslth66h5sv90pzs0j2a05p529w400hsf6tsltea9yn8cm99n980uf62jt9dc6agc844ljg36wm4sn02krxcn8kdjzunnfxg49qlp74r645ndqke45vym90qgtvtsscvwcdy700n2apw4nu7au24zx0j288cd7l0dj9wqwk4fyfj84z5gy968agf6jr0jt0unrgykx9pemytt6dtfqr8w8qge22k7akmjvdwh8pzfm5fjrxyrdg8c3ah39j5hppwnegtpcj6375tfs8avnd5vzq33u9pac8v5snen4z79vneh4ss29drgt3uryta2vcu5xd3df2ksmkjn2t8zekppem83rne5w4nzhh4dv3je34plq67fvc5dyvkdt3ux6j4ny3yqjq9vkwtum8lrp7juyznhhk3lc7g9c7m468dm0rzurdwnpmat6p40k3avx2lj8khzz4kuahu4c54pk7tlz05ycatqyzmngalc0760j3mf8ujgpnktdxcrzer7hqkf5qxhzmhxtnd0nld5dnl7uffjh5nseh7vfsr5eacq5mqzwv6hhdfjeyr4flgnclwuhze2vny6xlf2nsvlyvspguh7k6ax50lv6xj354dhnehpjgfm0ps3frrxr0dlyvxetat6mqd95x7lj5cnkxgpnftcf5yln4lvvt9n2nk0gm3795n03at6zg8v7yud03nyyp53fgezy5fzpnuwuneq7mhcvq2gq77uj83nqfld9xaa96mprs6rqkckmrjtcerxvcuel7ll0y4jewy7kspe0jyr8we9ukqf48pnnxsvy6xs07u5t3wkzkdf086847hr9vx7c07408ujhw9w8vfmfpjan2qdxqm3zycnlngzfsqs8ddgj3msmgcnzp0mr6jqvs5a7r7tgd0pj4fej2q7ca6469xepnnvwpcr8yhph"

# Parse address from CUSTOM_USER_CONFIG if provided
if [[ ! -z "$CUSTOM_USER_CONFIG" ]]; then
    # Extract address from --address parameter
    ADDRESS=$(echo "$CUSTOM_USER_CONFIG" | grep -o '\--address [^ ]*' | awk '{print $2}')
    if [[ ! -z "$ADDRESS" ]]; then
        echo "Using address from CUSTOM_USER_CONFIG: $ADDRESS"
    else
        ADDRESS="$DEFAULT_ADDRESS"
        echo "No address found in CUSTOM_USER_CONFIG, using default: $ADDRESS"
    fi
    
    # Extract GPU selection from --gpu-select parameter
    GPU_SELECT=$(echo "$CUSTOM_USER_CONFIG" | grep -o '\--gpu-select [^ ]*' | awk '{print $2}')
    if [[ ! -z "$GPU_SELECT" ]]; then
        echo "Using GPU selection from CUSTOM_USER_CONFIG: $GPU_SELECT"
        # Convert comma-separated string to JSON array format [0,2]
        GPU_ARRAY=$(echo "$GPU_SELECT" | sed 's/,/,/g')
        GPU_CONFIG="\"select\": [$GPU_ARRAY]"
    else
        echo "No GPU selection found in CUSTOM_USER_CONFIG, using all GPUs"
        GPU_CONFIG="\"option\": \"all\""
    fi
else
    ADDRESS="$DEFAULT_ADDRESS"
    echo "CUSTOM_USER_CONFIG not provided, using default address: $ADDRESS"
    GPU_CONFIG="\"option\": \"all\""
    echo "Using default GPU configuration: all GPUs"
fi

# Generate config.json dynamically
cat > "$CUSTOM_CONFIG_FILENAME" << EOF
{
  "selected": ["npt-gpu"],
  "algo_list": [
    {
      "id": "npt-gpu",
      "algo": "neptune",
      "pool": "$CUSTOM_URL",
      "worker_name": "$CUSTOM_TEMPLATE",
      "address": "$ADDRESS",
      "config": {
        "type": "gpu",
        $GPU_CONFIG
      }
    }
  ]
}
EOF

echo "Generated config.json with:"
echo "  Pool: $CUSTOM_URL"
echo "  Worker: $CUSTOM_TEMPLATE"
echo "  Address: $ADDRESS"

