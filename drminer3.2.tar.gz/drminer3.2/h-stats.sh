####################################################################################
###
### neptune
###
####################################################################################

#!/usr/bin/env bash

#######################
# MAIN script body
#######################

. /hive/miners/custom/drminer3.2/h-manifest.conf
algo=BLAKE3

LOG_FILE="${CUSTOM_LOG_BASENAME}.log"
MAX_DELAY=240
TIME_NOW=$(date +%s)

# Ищем последнюю строку со статистикой
stats_raw=$(grep -aF "Last 1m speed(KP/s)" "$LOG_FILE" | tail -n 1)

# Проверяем, что строка найдена
if [ -z "$stats_raw" ]; then
  echo "Нет данных в логе"
  khs=0
  stats="null"
else
  # Определяем время записи (первое поле в логе, если есть формат с датой)
  datetime_rep=$(echo "$stats_raw" | awk '{print $1}' | grep -E '^[0-9-]{10}' || echo "")
  if [ -n "$datetime_rep" ]; then
    time_rep=$(date -d "$datetime_rep" +%s 2>/dev/null || echo 0)
    diffTime=$((TIME_NOW - time_rep))
  else
    diffTime=0
  fi
  diffTime=$(echo "$diffTime" | tr -d '-')

  if [ "$diffTime" -lt "$MAX_DELAY" ]; then
    # Извлекаем скорость в KP/s и округляем
    total_hashrate=$(echo "$stats_raw" | grep -oP 'speed\(KP/s\)\s+\K[0-9]+\.[0-9]+' | awk '{printf("%.0f", $1 / 1000)}')

    # GPU данные (как в оригинале HiveOS)
    readarray -t gpu_stats < <(jq --slurp -r -c '.[] | .busids, .brand, .temp, .fan | join(" ")' "$GPU_STATS_JSON" 2>/dev/null)
    busids=(${gpu_stats[0]})
    brands=(${gpu_stats[1]})
    temps=(${gpu_stats[2]})
    fans=(${gpu_stats[3]})
    gpu_count=${#busids[@]}

    # Определяем тип GPU
    if [ "$(gpu-detect NVIDIA)" -gt 0 ]; then
      BRAND_MINER="nvidia"
    elif [ "$(gpu-detect AMD)" -gt 0 ]; then
      BRAND_MINER="amd"
    fi

    hash_arr=()
    busid_arr=()
    fan_arr=()
    temp_arr=()

    for ((i=0; i<gpu_count; i++)); do
      [[ "${brands[i]}" != "$BRAND_MINER" ]] && continue
      [[ "${busids[i]}" =~ ^([A-Fa-f0-9]+): ]]
      busid_arr+=($((16#${BASH_REMATCH[1]})))
      temp_arr+=(${temps[i]})
      fan_arr+=(${fans[i]})
      # Можно доработать при необходимости парсинга индивидуальных GPU скоростей
      hash_arr+=($((total_hashrate / gpu_count)))
    done

    hash_json=$(printf '%s\n' "${hash_arr[@]}" | jq -cs '.')
    bus_numbers=$(printf '%s\n' "${busid_arr[@]}" | jq -cs '.')
    fan_json=$(printf '%s\n' "${fan_arr[@]}" | jq -cs '.')
    temp_json=$(printf '%s\n' "${temp_arr[@]}" | jq -cs '.')

    uptime=$(( TIME_NOW - $(stat -c %Y "$CUSTOM_CONFIG_FILENAME") ))

    # Формируем JSON
    stats=$(jq -nc \
      --argjson hs "$hash_json" \
      --arg ver "$CUSTOM_VERSION" \
      --arg algo "$algo" \
      --arg ths "$total_hashrate" \
      --argjson bus_numbers "$bus_numbers" \
      --argjson fan "$fan_json" \
      --argjson temp "$temp_json" \
      --arg uptime "$uptime" \
      '{ $hs, hs_units: "KP/s", $algo, $ver, $uptime, $bus_numbers, $temp, $fan }')

    khs=$total_hashrate
  else
    khs=0
    stats="null"
  fi
fi

[[ -z $khs ]] && khs=0
[[ -z $stats ]] && stats="null"

echo "$stats"
