#!/bin/bash
set -e

required_version="2.39"
current_version=$(ldd --version | head -n1 | awk '{print $NF}')
lowest_version=$(printf '%s\n' "$required_version" "$current_version" | sort -V | head -n1)

# Сравнение версий с помощью sort -V
if [ "$lowest_version" = "$current_version" ] && [ "$current_version" != "$required_version" ]; then
    echo "GLIBC version is LOWER than $required_version"
    apt update
    apt install -y dirmngr gnupg gpg
    echo "deb [signed-by=/usr/share/keyrings/ubuntu-noble.gpg] http://archive.ubuntu.com/ubuntu noble main universe" | sudo tee /etc/apt/sources.list.d/noble-temp.list
    gpg --keyserver keyserver.ubuntu.com --recv-keys 3B4FE6ACC0B21F32
    gpg --export 3B4FE6ACC0B21F32 | sudo tee /usr/share/keyrings/ubuntu-noble.gpg > /dev/null
    gpg --keyserver keyserver.ubuntu.com --recv-keys 871920D1991BC93C
    gpg --export 871920D1991BC93C | sudo tee -a /usr/share/keyrings/ubuntu-noble.gpg > /dev/null
    apt update
    DEBIAN_FRONTEND=noninteractive apt install -y -t noble libjansson4 libstdc++6
    rm /etc/apt/sources.list.d/noble-temp.list
    apt update
else
    echo "GLIBC version is $current_version (OK, not lower than $required_version)"
fi
