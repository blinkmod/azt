#!/usr/bin/env bash

echo "WORKER_NAME =             $WORKER_NAME"
echo "CUSTOM_TEMPLATE =         $CUSTOM_TEMPLATE"
echo "CUSTOM_URL =              $CUSTOM_URL"
# echo "CUSTOM_PASS =             $CUSTOM_PASS"
# echo "CUSTOM_ALGO =           $CUSTOM_ALGO"
echo "CUSTOM_USER_CONFIG =      $CUSTOM_USER_CONFIG"
# echo "CUSTOM_CONFIG_FILENAME =  $CUSTOM_CONFIG_FILENAME"

[[ -e /hive/custom ]] && . /hive/custom/$CUSTOM_NAME/h-manifest.conf
[[ -e /hive/miners/custom ]] && . /hive/miners/custom/$CUSTOM_NAME/h-manifest.conf

conf=""
conf+="--pool $CUSTOM_URL --worker $CUSTOM_TEMPLATE"
[[ ! -z $CUSTOM_USER_CONFIG ]] && conf+=" $CUSTOM_USER_CONFIG"

echo "$conf"
echo "$conf" > $CUSTOM_CONFIG_FILENAME
