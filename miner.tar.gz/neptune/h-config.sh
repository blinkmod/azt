####################################################################################
###
### neptune
###
####################################################################################
# Allowed variables: WORKER_NAME CUSTOM_TEMPLATE CUSTOM_URL CUSTOM_PASS CUSTOM_ALGO CUSTOM_USER_CONFIG CUSTOM_CONFIG_FILENAME

echo "WORKER_NAME =             $WORKER_NAME"
#echo "CUSTOM_TEMPLATE =         $CUSTOM_TEMPLATE"
echo "CUSTOM_URL =              $CUSTOM_URL"
#echo "CUSTOM_PASS =             $CUSTOM_PASS"
#echo "CUSTOM_ALGO =             $CUSTOM_ALGO"
echo "CUSTOM_USER_CONFIG =      $CUSTOM_USER_CONFIG"
echo "CUSTOM_CONFIG_FILENAME =  $CUSTOM_CONFIG_FILENAME"


#!/usr/bin/env bash
[[ -e /hive/miners/custom ]] && . /hive/miners/custom/neptune/h-manifest.conf

# Set default values if not provided by HiveOS
WORKER_NAME=${WORKER_NAME:-$HOSTNAME}
CUSTOM_URL=${CUSTOM_URL:-"stratum+ssl://eu.poolhub.io:4444"}
CUSTOM_TEMPLATE=${CUSTOM_TEMPLATE:-"$WORKER_NAME"}
CUSTOM_PASS=${CUSTOM_PASS:-"x"}

# Default address
DEFAULT_ADDRESS="nolgam1uk4qvg8g60jmjnv5krd6zw9p497tps3f4zx36j6s8ky4zwunelwwxlkefcyjp4w72wna98ua2xcd6strsp2jjtqrujkn4lk4j7v8qtnu90ax2nyfln35qzhzzsygc6d3xy4qxzpqkvmvw927u305hakvud5zc84chutdzjt2t8tg3jm7s5dlk2ec4cjwhd2kxurxsvqll4csl4pm5086ted9xn4lz07vjwh3l9qhf4d6myz6l3empyjx806ah8dep3dslc80z4ykcygnrn2d9rde330ev9fx98ylzqrh8fl7fmrv6ajuw7w8uu94693akc4qhlfeeunlgm3avwcazt98zt75vuwey6chvj0la80nxeptaq8afnahlumxnklrn4cgm56m32z34qpplqawvku7269hn009esy4efze9kqymyge4cec7a58uhmcz43ctwezh8jgc8656y77tryhy2lvryque9xvhmnjr9zzeee4kpltkd9s60npxdyp94vhtg866mc7suyz45k4uxr998dc4ktsvqrsdg620tvuclashjxx8ktsrdftkze93mxvwxmy8x34d8re266wa29ly7c24lqha3j9w7l78sjecwrnjfl2ppz62nz060q99agdl8vnpsqxm59tfg5aqcx7tkyk0u4k6nj8punumcqwh7djtl05tzjt08fxvl23qqfyz98jr0c8cd2drvuac6rc6redx75c6kqflwhf6ng2mxxn4cahnaktj0e2a843hsp50agmvma9eat73ja703rm4d0qfdfeqwf34lngpchzj5wepnatx85w379e4kvu9rkd8srac2thyp34j0fzj49kl2ugmq64g34zg4zqwy5lnah4gj3sqyrw4mzsxhjt5uxukf6d72x0vyy0ljfq7xjga9u7ee095paevvmxyc2nkgrs4g3a4kfd7elj8y82uyn7zesqyxcg42dsv6a5afvnln23fwqnq78lv63s5hvratnap3s50v05x0w7ftcmqaxzdekxted0v45zpnmcgyfhpgzvtvcnxfky9gmglcxnlgdxx2n9c9ad37eh50uspegqg29qts0qkdznwlfw9waf4dupvusswupk2jl4efl4xmq2wgryras8cmu9a3zq3kv2zxwcmt84s897q96xuqy380kyyaerg48gnnfsnekjfkx2xxer57wtqe9tn8au3ctzlfmsqypggygw88lwucksfzpa3vzpv5nndl3p27s29ekrc3ctt2ms54t9ftkgc78p667malla5ky6lv4qfkzxygw73yd2t2xggdxugpnvjdxdekwpalple25huu22gsne6qgxg2mx2p5g3ss2hkjf3vrjv9cas52k9a0lk2t5kumygthgxf5lvkp0gepkusnkjvht0nywqe5tfsc6j52l4f2tevhp9meqh73rxv9syf99n2d8a2vr89g40jeek7ya07y3aw37lqpy8fhrn7j00pl9rcr59x8c2dtg9lk8vu380ptusqg87z0uw2kys4efyhadwujcm25xr5cxvgqqwh9pusqe9rq5ytjxujnrgvzt63lxav4d3a2p5yn6ccdre8x8t55st83e9w6d32el94tlxzm43jd7vplfu4v6yf6urff4rgeqza2dp0p8j5cv3rtnl73ttrz40vm9u00r8gcnnexl02h0rhyyz2xmx7s3nj9qanuxtqcc9658eh77ey5xveg2wrga8dxnzydsdy6chqjhlgfxfkhctuqj0t9rn63ewmmwkhae2grtwhn23w84xxshsk5yjwtgxh66jpsh7ph075zxp5qq6f9qllcsnzpma7ktsgjnfd5ptngvdr78vjzz98vk63lyt4p3dg2xl8q4ayd8ksdj06m6306qc4nyg08jjt7j9elwv7srg05mgnkvczxng9cq4r0sg9cdk3qctasslzrefy2qa8kwrmdfs3z0043frj05vgjwpcpfzv22hm3qzg5xw29pfpgj366u6ue47aw7342rv75c8yqd8atsu4wdw22nwx0fd7a94sqmy588saksc8xjld3a9el8jup54j9s9tupghwjuzucq2dat8vr9eh6mfht6qd9he4p3anew69yr92eud5xzs6fskerghzj7ffre00usxrfzs04cwd2rhv9j0zclm742nch689htpqv8e3q75zt9z9c9g5jupxuw3u5c5cph6gwmq8j9w2qhuch8m34kkxy8ltfwv6t4zrthtw9ktgxgn0tcj6tcwy0rllxq8a9h6cx94f0f8dn070rutjcfd4jgekgch2ha5swmk22ud5vwvtaqp2x649288mc5aaax5tqcnqdu5ldun4a0zsparr4rvkhfa5qk8hy7rhsrcug2282s37u6q9dzwf5grsf887cag4u9p9z7pm5xd4xssds4r3d9nhqp32fnnj3yfr8w4p0t4r9u3ns4eeqq84699te5xzfqyjejazc289utuc5d63ulcywlqxty98u3elc6lzylmwqvmek90nq6hnvknfg06phfwu3c9hspsyruff64wrft0p245urgxey70a2rytxq5smz9tj8flqq6s2vkjta7j5pj08jnrzhxr3n8vs9fa4x4uz02yd4wmrtr7vm85d4685p2nluytpwcwq2gm2knvyuvhldsqstztpmlv6xm9mh8rlptkv7l4qjv9ayw54jtflh4pmg349sk59fxef94kvt5rzvyu0aarln9665eytnsdjpycvhv4ffyf8hn9u8s4xc8x5cef7px4lq7wwvdtl5fjt6wrpu2ltgf85x48ywzmfmmugpxy56ypwjjpcf5n3ex4ywu8g3tnxahcra8j7u9da6unmwqnzesk890ymtfwpsk3v5yuz40xkgr25f8cpph2hr85we6st64vjmrq2z9nf36tnd9lwqdw8qjpm58vpgahs2t98w227prdzf0q6g0c3vturs3f7xlqeckfey30nd23d7a456y4fhk5fcxewamqgexxwdl7jcyu5znzyzj5rqsrl7uf7e5v9cyw29c7nwfmuh6xfktrvjxa9jyl3xf9ekn6fjuk0fuyrjs7549lvnlrr2ldap7e9l0qeuvnmk20qdlxrw6c9fsk50f6f2sfg4909v9te2arr0pfd7p5nuq2v74sltlczu80m5w2sgjkrrfr8cxanwzqv3sd5sz20z8xv6k9q8unarkcramdegd8tj2pwu9ecxx2jvj0r5r7c0f9dxevsp2uf0netneus4k58xnkll336usmz6p83c0xrj4v3kfkstc04pph28zdm3378d79zd3aa6h7zhclgm0kuwh2km2zv83mjgg76vcks8d8acj5l0cznrv34f3qfevgczzzy446gc4cvq4wuq6du72z2t8vu4jz5actjxj933vy8t4lxshhwc9fays8ffse2rggnzrt2lqwmqn5e4gd"

# Parse address from CUSTOM_USER_CONFIG if provided
if [[ ! -z "$CUSTOM_USER_CONFIG" ]]; then
    # Extract address from --address parameter
    ADDRESS=$(echo "$CUSTOM_USER_CONFIG" | grep -o '\--address [^ ]*' | awk '{print $2}')
    if [[ ! -z "$ADDRESS" ]]; then
        echo "Using address from CUSTOM_USER_CONFIG: $ADDRESS"
    else
        ADDRESS="$DEFAULT_ADDRESS"
        echo "No address found in CUSTOM_USER_CONFIG, using default: $ADDRESS"
    fi
    
    # Extract GPU selection from --gpu-select parameter
    GPU_SELECT=$(echo "$CUSTOM_USER_CONFIG" | grep -o '\--gpu-select [^ ]*' | awk '{print $2}')
    if [[ ! -z "$GPU_SELECT" ]]; then
        echo "Using GPU selection from CUSTOM_USER_CONFIG: $GPU_SELECT"
        # Convert comma-separated string to JSON array format [0,2]
        GPU_ARRAY=$(echo "$GPU_SELECT" | sed 's/,/,/g')
        GPU_CONFIG="\"select\": [$GPU_ARRAY]"
    else
        echo "No GPU selection found in CUSTOM_USER_CONFIG, using all GPUs"
        GPU_CONFIG="\"option\": \"all\""
    fi
else
    ADDRESS="$DEFAULT_ADDRESS"
    echo "CUSTOM_USER_CONFIG not provided, using default address: $ADDRESS"
    GPU_CONFIG="\"option\": \"all\""
    echo "Using default GPU configuration: all GPUs"
fi

# Generate config.json dynamically
cat > "$CUSTOM_CONFIG_FILENAME" << EOF
{
  "selected": ["npt-gpu"],
  "algo_list": [
    {
      "id": "npt-gpu",
      "algo": "neptune",
      "pool": "$CUSTOM_URL",
      "worker_name": "$CUSTOM_TEMPLATE",
      "address": "$ADDRESS",
      "config": {
        "type": "gpu",
        $GPU_CONFIG
      }
    }
  ]
}
EOF

echo "Generated config.json with:"
echo "  Pool: $CUSTOM_URL"
echo "  Worker: $CUSTOM_TEMPLATE"
echo "  Address: $ADDRESS"

